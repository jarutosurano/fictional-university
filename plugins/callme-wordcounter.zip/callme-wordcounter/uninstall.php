<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('cwc_location');
delete_option('cwc_headline');
delete_option('cwc_wordcount');
delete_option('cwc_charcount');
delete_option('cwc_readtime');
